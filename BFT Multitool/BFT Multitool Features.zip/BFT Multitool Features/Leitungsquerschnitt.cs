﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BFT_Multitool_Features
{
    class Class1
    {

         static void Man()
        {
            double wiederstand = 0, volt = 0, strom = 0, länge = 0;

            Console.WriteLine("Bitte wählen sie nun das Material \n(1) Kupfer \n(2) Gold \n(3) Aluminium \n (4) Silber \n (4) Zink \n (5) Nickel \n (6) Platin \n (7) Zinn \n (0) Anderes");
            double material = Convert.ToDouble((Console.ReadLine()));
            switch (material)
            {
                case 1:
                    wiederstand = 56;
                    break;

                case 2:
                    wiederstand = 45.45;
                    break;

                case 3:
                    wiederstand = 36;
                    break;

                case 4:
                    wiederstand = 16;
                    break;

                case 5:
                    wiederstand = 10.5;
                    break;

                case 6:
                    wiederstand = 10.2;
                    break;

                case 7:
                    wiederstand = 8.7;
                    break;

                case 0:
                    Console.WriteLine("Geben sie bitte die Leitfähigkeit des Material in Siemens pro Meter bei 20°C an");
                    wiederstand = Convert.ToDouble(Console.ReadLine());
                    break;

                default:
                    break;
            }

            Console.WriteLine("Bitte wählen sie den Strom in Amper aus! \n(1) 2 A \n(2) 4 A \n(3) 10 A \n(4) 13 A \n(5) 16 A \n(6) 20 A \n(7) 25 A \n(8) 32 A \n(9)35 A \n(10) 50 \n(11) 63 A \n(0) Anderes");
            double s_auswahl = Convert.ToDouble((Console.ReadLine()));
            switch (s_auswahl)
            {
                case 1:
                    strom = 2;
                    break;

                case 2:
                    strom = 4;
                    break;

                case 3:
                    strom = 10;
                    break;

                case 4:
                    strom = 13;
                    break;

                case 5:
                    strom = 16;
                    break;

                case 6:
                    strom = 20;
                    break;

                case 7:
                    strom = 25;
                    break;

                case 8:
                    strom = 32;
                    break;

                case 9:
                    strom = 35;
                    break;

                case 10:
                    strom = 50;
                    break;

                case 11:
                    strom = 63;
                    break;

                case 0:
                    strom = Convert.ToDouble(Console.ReadLine());
                    break;

                default:
                    break;
            }

            Console.WriteLine("Bitte wählen sie die Spannung in Volt aus! \n(1) 12 V \n(2) 24 V \n(3) 115 V \n(4) 230 V \n(5) 400 V \n(0) Anderes");
            double v_auswahl = Convert.ToDouble((Console.ReadLine()));
            switch (v_auswahl)
            {
                case 1:
                    volt = 12;
                    break;

                case 2:
                    volt = 24;
                    break;

                case 3:
                    volt = 115;
                    break;

                case 4:
                    volt = 230;
                    break;

                case 5:
                    volt = 400;
                    break;

                case 0:
                    volt = Convert.ToDouble(Console.ReadLine());
                    break;

                default:
                    break;
            }

            Console.WriteLine("Bitte wählen sie die Länge in Meter aus! \n(1) 25m \n(2) 50m \n(0) Anderes");
            double l_auswahl = Convert.ToDouble((Console.ReadLine()));
            switch (l_auswahl)
            {
                case 1:
                    länge = 25;
                    break;

                case 2:
                    länge = 50;
                    break;

                case 0:
                    länge = Convert.ToDouble(Console.ReadLine());
                    break;

                default:
                    break;
            }

            Console.WriteLine("Bitte geben sie den Spannungsfall in Volt ein!");
            double spannungsfall = Convert.ToDouble((Console.ReadLine()));
            

            double leitungsquerschnitt = 2*länge*strom/wiederstand/(spannungsfall / (volt / 100));

            Console.WriteLine("Der Kabelquerschnitt beträgt {0} mm²",leitungsquerschnitt);
        }
    }
}